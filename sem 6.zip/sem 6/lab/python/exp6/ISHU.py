#Example
#Save this code in a file named mymodule.py

def ishu(name):
  print("Hello, " + name)