import ISHU as i

i.ishu("ishu kumar")