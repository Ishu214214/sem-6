package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
EditText u ;
EditText p ;
Button b ;
TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        u = findViewById(R.id.username);
        p= findViewById(R.id.password);
        b = findViewById(R.id.button);
        t= findViewById(R.id.textView3);
    }
public void login(View v)
{
    String uname = u.getText().toString();
    String pass = p.getText().toString();
    if (uname.equals("admin") && pass.equals("admin"))
    {
        t.setText("Login Sucessful");
    }
    else
    {
        t.setText("Login not Sucessful");
    }

}

}